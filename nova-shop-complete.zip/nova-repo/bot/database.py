"""Async SQLite storage for Nova Shop Bot (aiosqlite, per-operation connections).

Money is always integer cents. Rows are dict-like (aiosqlite.Row).
"""
import os
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone

import aiosqlite

import config
from utils import utcnow_iso, new_ref_code

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, tg_id INTEGER UNIQUE NOT NULL, name TEXT,
  phone TEXT, address TEXT, is_blocked INTEGER DEFAULT 0,
  ref_code TEXT UNIQUE, referred_by INTEGER REFERENCES users(id),
  role_mask INTEGER DEFAULT 0, created_at TEXT);
CREATE TABLE IF NOT EXISTS categories(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, emoji TEXT DEFAULT '\U0001f4e6',
  sort INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS products(
  id INTEGER PRIMARY KEY, category_id INTEGER REFERENCES categories(id),
  name TEXT NOT NULL, description TEXT DEFAULT '', photo_file_id TEXT,
  price_cents INTEGER NOT NULL, old_price_cents INTEGER,
  kind TEXT NOT NULL DEFAULT 'physical',
  stock INTEGER NOT NULL DEFAULT -1,
  rating_sum INTEGER DEFAULT 0, rating_count INTEGER DEFAULT 0,
  is_active INTEGER DEFAULT 1, created_at TEXT);
CREATE TABLE IF NOT EXISTS product_values(
  id INTEGER PRIMARY KEY, product_id INTEGER REFERENCES products(id) ON DELETE CASCADE,
  value TEXT NOT NULL, is_used INTEGER DEFAULT 0, used_in_order INTEGER,
  UNIQUE(product_id, value));
CREATE TABLE IF NOT EXISTS cart_items(
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  product_id INTEGER REFERENCES products(id) ON DELETE CASCADE,
  qty INTEGER NOT NULL, UNIQUE(user_id, product_id));
CREATE TABLE IF NOT EXISTS wishlist(
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  product_id INTEGER REFERENCES products(id) ON DELETE CASCADE,
  UNIQUE(user_id, product_id));
CREATE TABLE IF NOT EXISTS promos(
  id INTEGER PRIMARY KEY, code TEXT UNIQUE NOT NULL, kind TEXT NOT NULL,
  value INTEGER NOT NULL,
  max_uses INTEGER DEFAULT 0, used_count INTEGER DEFAULT 0,
  expires_at TEXT, is_active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS promo_usages(promo_id INTEGER, user_id INTEGER,
  used_at TEXT, UNIQUE(promo_id, user_id));
CREATE TABLE IF NOT EXISTS orders(
  id INTEGER PRIMARY KEY, user_id INTEGER REFERENCES users(id),
  status TEXT NOT NULL DEFAULT 'pending',
  subtotal_cents INTEGER, discount_cents INTEGER DEFAULT 0, total_cents INTEGER,
  payment_method TEXT,
  delivery_kind TEXT,
  address TEXT, phone TEXT, promo_code TEXT,
  created_at TEXT, updated_at TEXT);
CREATE TABLE IF NOT EXISTS order_items(
  order_id INTEGER REFERENCES orders(id) ON DELETE CASCADE,
  product_id INTEGER, name TEXT, qty INTEGER, price_cents INTEGER,
  delivered_value TEXT);
CREATE TABLE IF NOT EXISTS payments(
  id INTEGER PRIMARY KEY, provider TEXT NOT NULL,
  external_id TEXT NOT NULL, user_id INTEGER, order_id INTEGER,
  amount_cents INTEGER, currency TEXT, status TEXT DEFAULT 'pending',
  created_at TEXT, UNIQUE(provider, external_id));
CREATE TABLE IF NOT EXISTS reviews(
  user_id INTEGER, product_id INTEGER REFERENCES products(id) ON DELETE CASCADE,
  rating INTEGER CHECK(rating BETWEEN 1 AND 5), text TEXT, created_at TEXT,
  UNIQUE(user_id, product_id));
CREATE TABLE IF NOT EXISTS referral_earnings(
  id INTEGER PRIMARY KEY, referrer_id INTEGER, referee_id INTEGER,
  order_id INTEGER UNIQUE, amount_cents INTEGER, created_at TEXT);
-- One-time first-paid-order credit claim per referee (race guard).
CREATE TABLE IF NOT EXISTS referral_claims(
  referee_id INTEGER PRIMARY KEY, claimed_at TEXT);
CREATE TABLE IF NOT EXISTS stock_alerts(
  user_id INTEGER NOT NULL, product_id INTEGER NOT NULL,
  created_at TEXT DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, product_id));
CREATE TABLE IF NOT EXISTS tonconnect_pending(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, sender TEXT NOT NULL,
  amount_nano INTEGER NOT NULL, items_json TEXT NOT NULL, promo_code TEXT,
  created_at TEXT DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS audit_log(
  id INTEGER PRIMARY KEY, ts TEXT, actor_tg_id INTEGER, action TEXT, details TEXT);
CREATE TABLE IF NOT EXISTS kv(key TEXT PRIMARY KEY, value TEXT);
-- Crypto payments (SPEC2): never alter v1 tables above.
CREATE TABLE IF NOT EXISTS crypto_deposits(
  id INTEGER PRIMARY KEY, order_id INTEGER REFERENCES orders(id) ON DELETE CASCADE,
  chain TEXT NOT NULL, address TEXT NOT NULL, derivation_index INTEGER,
  memo TEXT, expected_crypto TEXT NOT NULL, expected_usd_cents INTEGER NOT NULL,
  status TEXT DEFAULT 'pending',
  txid TEXT, confirmations INTEGER DEFAULT 0, seen_amount_crypto TEXT,
  created_at TEXT, expires_at TEXT, UNIQUE(chain, txid));
CREATE TABLE IF NOT EXISTS cryptobot_invoices(
  id INTEGER PRIMARY KEY, order_id INTEGER REFERENCES orders(id) ON DELETE CASCADE,
  invoice_id INTEGER UNIQUE NOT NULL, asset TEXT, amount TEXT,
  status TEXT DEFAULT 'active', created_at TEXT);
"""


class Database:
    def __init__(self, path: str):
        self.path = path
        parent = os.path.dirname(os.path.abspath(path))
        if parent:
            os.makedirs(parent, exist_ok=True)

    @asynccontextmanager
    async def _db(self):
        """Per-operation connection: row factory + FK pragmas, auto-closed."""
        async with aiosqlite.connect(self.path) as db:
            db.row_factory = aiosqlite.Row
            await db.execute("PRAGMA foreign_keys = ON")
            yield db

    async def create_tables(self):
        async with self._db() as db:
            await db.executescript(SCHEMA)
            await db.execute(
                "INSERT OR IGNORE INTO kv(key, value) VALUES ('maintenance_mode','0')")
            await db.execute(
                "INSERT OR IGNORE INTO kv(key, value) VALUES ('referral_percent', ?)",
                (str(config.REFERRAL_PERCENT),),
            )
            await db.commit()

    # ------------------------------------------------------------- kv ---
    async def kv_get(self, key: str, default=None):
        async with self._db() as db:
            async with db.execute("SELECT value FROM kv WHERE key=?", (key,)) as cur:
                row = await cur.fetchone()
                return row["value"] if row else default

    async def kv_set(self, key: str, value: str):
        async with self._db() as db:
            await db.execute(
                "INSERT INTO kv(key, value) VALUES (?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, value),
            )
            await db.commit()

    async def maintenance_on(self) -> bool:
        return (await self.kv_get("maintenance_mode", "0")) == "1"

    async def referral_percent(self) -> int:
        try:
            return int(await self.kv_get("referral_percent",
                                         str(config.REFERRAL_PERCENT)))
        except (TypeError, ValueError):
            return config.REFERRAL_PERCENT

    # ---------------------------------------------------------- users ---
    async def get_user_by_tg(self, tg_id: int):
        async with self._db() as db:
            async with db.execute("SELECT * FROM users WHERE tg_id=?",
                                  (tg_id,)) as cur:
                return await cur.fetchone()

    async def get_user(self, user_id: int):
        async with self._db() as db:
            async with db.execute("SELECT * FROM users WHERE id=?",
                                  (user_id,)) as cur:
                return await cur.fetchone()

    async def get_user_by_ref_code(self, code: str):
        async with self._db() as db:
            async with db.execute("SELECT * FROM users WHERE ref_code=?",
                                  (code,)) as cur:
                return await cur.fetchone()

    async def create_user(self, tg_id: int, name: str, referred_by=None):
        for _ in range(5):
            code = new_ref_code()
            try:
                async with self._db() as db:
                    await db.execute(
                        "INSERT INTO users(tg_id, name, ref_code, referred_by, created_at)"
                        " VALUES (?, ?, ?, ?, ?)",
                        (tg_id, name, code, referred_by, utcnow_iso()),
                    )
                    await db.commit()
                break
            except aiosqlite.IntegrityError:
                continue  # ref_code collision (or tg_id race) — retry
        return await self.get_user_by_tg(tg_id)

    async def update_user(self, user_id: int, **fields):
        allowed = {"name", "phone", "address", "is_blocked", "role_mask"}
        sets = [f"{k}=?" for k in fields if k in allowed]
        if not sets:
            return
        vals = [fields[k] for k in fields if k in allowed]
        async with self._db() as db:
            await db.execute(
                f"UPDATE users SET {', '.join(sets)} WHERE id=?",
                (*vals, user_id),
            )
            await db.commit()

    async def count_users(self) -> int:
        async with self._db() as db:
            async with db.execute("SELECT COUNT(*) c FROM users") as cur:
                return (await cur.fetchone())["c"]

    async def count_new_users_24h(self) -> int:
        async with self._db() as db:
            async with db.execute(
                "SELECT COUNT(*) c FROM users WHERE created_at >= "
                "datetime('now', '-1 day')") as cur:
                return (await cur.fetchone())["c"]

    async def count_blocked_users(self) -> int:
        async with self._db() as db:
            async with db.execute(
                "SELECT COUNT(*) c FROM users WHERE is_blocked=1") as cur:
                return (await cur.fetchone())["c"]

    async def all_active_tg_ids(self):
        async with self._db() as db:
            async with db.execute(
                "SELECT tg_id FROM users WHERE is_blocked=0") as cur:
                return [r["tg_id"] for r in await cur.fetchall()]

    # ----------------------------------------------------- categories ---
    async def list_categories(self):
        async with self._db() as db:
            async with db.execute(
                "SELECT * FROM categories ORDER BY sort, name") as cur:
                return await cur.fetchall()

    async def get_category(self, cid: int):
        async with self._db() as db:
            async with db.execute("SELECT * FROM categories WHERE id=?",
                                  (cid,)) as cur:
                return await cur.fetchone()

    async def add_category(self, name: str, emoji: str = "\U0001f4e6") -> int:
        async with self._db() as db:
            cur = await db.execute(
                "INSERT INTO categories(name, emoji) VALUES (?, ?)", (name, emoji))
            await db.commit()
            return cur.lastrowid

    async def rename_category(self, cid: int, name: str):
        async with self._db() as db:
            await db.execute("UPDATE categories SET name=? WHERE id=?",
                             (name, cid))
            await db.commit()

    async def delete_category(self, cid: int):
        async with self._db() as db:
            await db.execute("DELETE FROM categories WHERE id=?", (cid,))
            await db.commit()

    # ------------------------------------------------------- products ---
    async def get_product(self, pid: int):
        async with self._db() as db:
            async with db.execute("SELECT * FROM products WHERE id=?",
                                  (pid,)) as cur:
                return await cur.fetchone()

    async def list_products(self, category_id: int, limit: int, offset: int):
        async with self._db() as db:
            async with db.execute(
                "SELECT * FROM products WHERE category_id=? AND is_active=1"
                " ORDER BY id LIMIT ? OFFSET ?",
                (category_id, limit, offset)) as cur:
                return await cur.fetchall()

    async def count_active_products(self, category_id: int) -> int:
        async with self._db() as db:
            async with db.execute(
                "SELECT COUNT(*) c FROM products WHERE category_id=? AND is_active=1",
                (category_id,)) as cur:
                return (await cur.fetchone())["c"]

    async def count_products_in_category(self, cid: int) -> int:
        async with self._db() as db:
            async with db.execute(
                "SELECT COUNT(*) c FROM products WHERE category_id=?",
                (cid,)) as cur:
                return (await cur.fetchone())["c"]

    async def search_products(self, q: str, limit: int, offset: int):
        like = f"%{q}%"
        async with self._db() as db:
            async with db.execute(
                "SELECT * FROM products WHERE is_active=1 AND name LIKE ?"
                " ORDER BY id LIMIT ? OFFSET ?",
                (like, limit, offset)) as cur:
                return await cur.fetchall()

    async def count_search(self, q: str) -> int:
        like = f"%{q}%"
        async with self._db() as db:
            async with db.execute(
                "SELECT COUNT(*) c FROM products WHERE is_active=1 AND name LIKE ?",
                (like,)) as cur:
                return (await cur.fetchone())["c"]

    async def list_all_products_in_category(self, category_id: int, limit: int,
                                            offset: int):
        async with self._db() as db:
            async with db.execute(
                "SELECT * FROM products WHERE category_id=?"
                " ORDER BY id DESC LIMIT ? OFFSET ?",
                (category_id, limit, offset)) as cur:
                return await cur.fetchall()

    async def list_all_products(self, limit: int, offset: int):
        async with self._db() as db:
            async with db.execute(
                "SELECT * FROM products ORDER BY id DESC LIMIT ? OFFSET ?",
                (limit, offset)) as cur:
                return await cur.fetchall()

    async def count_all_products(self) -> int:
        async with self._db() as db:
            async with db.execute("SELECT COUNT(*) c FROM products") as cur:
                return (await cur.fetchone())["c"]

    async def add_product(self, *, category_id, name, description="", photo_file_id=None,
                          price_cents, old_price_cents=None, kind="physical",
                          stock=-1) -> int:
        async with self._db() as db:
            cur = await db.execute(
                "INSERT INTO products(category_id, name, description, photo_file_id,"
                " price_cents, old_price_cents, kind, stock, created_at)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (category_id, name, description, photo_file_id, price_cents,
                 old_price_cents, kind, stock, utcnow_iso()),
            )
            await db.commit()
            return cur.lastrowid

    async def update_product(self, pid: int, **fields):
        allowed = {"category_id", "name", "description", "photo_file_id",
                   "price_cents", "old_price_cents", "kind", "stock",
                   "is_active", "rating_sum", "rating_count"}
        sets = [f"{k}=?" for k in fields if k in allowed]
        if not sets:
            return
        vals = [fields[k] for k in fields if k in allowed]
        async with self._db() as db:
            await db.execute(
                f"UPDATE products SET {', '.join(sets)} WHERE id=?",
                (*vals, pid),
            )
            await db.commit()

    async def delete_product(self, pid: int):
        async with self._db() as db:
            await db.execute("DELETE FROM products WHERE id=?", (pid,))
            await db.commit()

    async def decrement_stock(self, product_id: int, qty: int) -> int:
        """Atomically decrement physical stock by qty.

        Single conditional statement: concurrent checkouts cannot oversell.
        Returns affected rows: 1 on success (or for unlimited stock),
        0 when stock is insufficient. stock = -1 (unlimited/digital) is
        matched but never modified.
        """
        async with self._db() as db:
            cur = await db.execute(
                "UPDATE products SET stock = CASE WHEN stock = -1"
                " THEN -1 ELSE stock - ? END"
                " WHERE id=? AND (stock = -1 OR stock >= ?)",
                (qty, product_id, qty),
            )
            await db.commit()
            return cur.rowcount

    async def top_products(self, limit: int = 5):
        async with self._db() as db:
            async with db.execute(
                "SELECT p.name, SUM(oi.qty) qty, SUM(oi.qty * oi.price_cents) revenue"
                " FROM order_items oi JOIN products p ON p.id = oi.product_id"
                " JOIN orders o ON o.id = oi.order_id"
                " WHERE o.status != 'cancelled'"
                " GROUP BY oi.product_id ORDER BY qty DESC LIMIT ?",
                (limit,)) as cur:
                return await cur.fetchall()

    # ------------------------------------------------- product values ---
    async def add_product_values(self, product_id: int, values):
        async with self._db() as db:
            await db.executemany(
                "INSERT OR IGNORE INTO product_values(product_id, value) VALUES (?, ?)",
                [(product_id, v) for v in values if v],
            )
            await db.commit()

    async def unused_values_count(self, product_id: int) -> int:
        async with self._db() as db:
            async with db.execute(
                "SELECT COUNT(*) c FROM product_values"
                " WHERE product_id=? AND is_used=0",
                (product_id,)) as cur:
                return (await cur.fetchone())["c"]

    async def pop_product_values(self, product_id: int, qty: int, order_id: int):
        """Atomically claim `qty` unused values. Returns list or None if short."""
        async with self._db() as db:
            await db.execute("BEGIN IMMEDIATE")
            try:
                async with db.execute(
                    "SELECT id, value FROM product_values"
                    " WHERE product_id=? AND is_used=0 ORDER BY id LIMIT ?",
                    (product_id, qty)) as cur:
                    rows = await cur.fetchall()
                if len(rows) < qty:
                    await db.execute("ROLLBACK")
                    return None
                ids = [r["id"] for r in rows]
                await db.execute(
                    f"UPDATE product_values SET is_used=1, used_in_order=?"
                    f" WHERE id IN ({','.join('?' * len(ids))})",
                    (order_id, *ids),
                )
                await db.execute("COMMIT")
                return [r["value"] for r in rows]
            except Exception:
                await db.execute("ROLLBACK")
                raise

    # ----------------------------------------------------------- cart ---
    async def cart_add(self, user_id: int, product_id: int, qty: int = 1):
        async with self._db() as db:
            await db.execute(
                "INSERT INTO cart_items(user_id, product_id, qty) VALUES (?, ?, ?)"
                " ON CONFLICT(user_id, product_id) DO UPDATE SET qty=qty+excluded.qty",
                (user_id, product_id, qty),
            )
            await db.commit()

    async def cart_set_qty(self, user_id: int, product_id: int, qty: int):
        async with self._db() as db:
            if qty <= 0:
                await db.execute(
                    "DELETE FROM cart_items WHERE user_id=? AND product_id=?",
                    (user_id, product_id),
                )
            else:
                await db.execute(
                    "INSERT INTO cart_items(user_id, product_id, qty) VALUES (?, ?, ?)"
                    " ON CONFLICT(user_id, product_id) DO UPDATE SET qty=excluded.qty",
                    (user_id, product_id, qty),
                )
            await db.commit()

    async def cart_remove(self, user_id: int, product_id: int):
        await self.cart_set_qty(user_id, product_id, 0)

    async def cart_clear(self, user_id: int):
        async with self._db() as db:
            await db.execute("DELETE FROM cart_items WHERE user_id=?", (user_id,))
            await db.commit()

    async def stock_alert_add(self, user_id: int, product_id: int):
        async with self._db() as db:
            await db.execute(
                "INSERT OR IGNORE INTO stock_alerts(user_id, product_id) VALUES(?, ?)",
                (user_id, product_id))
            await db.commit()

    async def stock_alert_remove(self, user_id: int, product_id: int):
        async with self._db() as db:
            await db.execute(
                "DELETE FROM stock_alerts WHERE user_id=? AND product_id=?",
                (user_id, product_id))
            await db.commit()

    async def stock_alerts_for_product(self, product_id: int):
        async with self._db() as db:
            async with db.execute(
                "SELECT user_id FROM stock_alerts WHERE product_id=?", (product_id,)) as cur:
                return [r[0] async for r in cur]

    async def stock_alerts_clear_product(self, product_id: int):
        async with self._db() as db:
            await db.execute("DELETE FROM stock_alerts WHERE product_id=?", (product_id,))
            await db.commit()

    async def tonconnect_pending_add(self, user_id: int, sender: str,
                                     amount_nano: int, items: list,
                                     promo_code: str = None):
        import json
        async with self._db() as db:
            await db.execute(
                "INSERT INTO tonconnect_pending(user_id, sender, amount_nano, items_json, promo_code)"
                " VALUES (?, ?, ?, ?, ?)",
                (user_id, sender, amount_nano, json.dumps(items), promo_code))
            await db.commit()

    async def tonconnect_pending_list(self):
        import json
        async with self._db() as db:
            async with db.execute(
                "SELECT * FROM tonconnect_pending ORDER BY created_at") as cur:
                rows = [dict(r) async for r in cur]
        for r in rows:
            try:
                r["items"] = json.loads(r["items_json"] or "[]")
            except Exception:
                r["items"] = []
        return rows

    async def tonconnect_pending_remove(self, pid: int):
        async with self._db() as db:
            await db.execute("DELETE FROM tonconnect_pending WHERE id=?", (pid,))
            await db.commit()

    async def cart_items(self, user_id: int):
        async with self._db() as db:
            async with db.execute(
                "SELECT ci.product_id, ci.qty, p.name, p.price_cents, p.stock,"
                " p.kind, p.is_active, p.photo_file_id"
                " FROM cart_items ci JOIN products p ON p.id = ci.product_id"
                " WHERE ci.user_id=? ORDER BY ci.rowid",
                (user_id,)) as cur:
                return await cur.fetchall()

    async def cart_count(self, user_id: int) -> int:
        async with self._db() as db:
            async with db.execute(
                "SELECT COALESCE(SUM(qty),0) s FROM cart_items WHERE user_id=?",
                (user_id,)) as cur:
                return (await cur.fetchone())["s"]

    # ------------------------------------------------------- wishlist ---
    async def wishlist_toggle(self, user_id: int, product_id: int) -> bool:
        """Returns True if now in wishlist."""
        async with self._db() as db:
            async with db.execute(
                "SELECT 1 FROM wishlist WHERE user_id=? AND product_id=?",
                (user_id, product_id)) as cur:
                exists = await cur.fetchone()
            if exists:
                await db.execute(
                    "DELETE FROM wishlist WHERE user_id=? AND product_id=?",
                    (user_id, product_id))
                await db.commit()
                return False
            await db.execute(
                "INSERT OR IGNORE INTO wishlist(user_id, product_id) VALUES (?, ?)",
                (user_id, product_id))
            await db.commit()
            return True

    async def wishlist_has(self, user_id: int, product_id: int) -> bool:
        async with self._db() as db:
            async with db.execute(
                "SELECT 1 FROM wishlist WHERE user_id=? AND product_id=?",
                (user_id, product_id)) as cur:
                return await cur.fetchone() is not None

    async def wishlist_list(self, user_id: int):
        async with self._db() as db:
            async with db.execute(
                "SELECT p.* FROM wishlist w JOIN products p ON p.id=w.product_id"
                " WHERE w.user_id=? AND p.is_active=1 ORDER BY w.rowid DESC",
                (user_id,)) as cur:
                return await cur.fetchall()

    # --------------------------------------------------------- promos ---
    async def get_promo(self, code: str):
        async with self._db() as db:
            async with db.execute(
                "SELECT * FROM promos WHERE code=? COLLATE NOCASE",
                (code.strip(),)) as cur:
                return await cur.fetchone()

    async def validate_promo(self, code: str, user_id: int, subtotal_cents: int):
        """Returns (ok, message, discount_cents, promo_row)."""
        promo = await self.get_promo(code)
        if not promo or not promo["is_active"]:
            return False, "invalid", 0, None
        if promo["expires_at"] and promo["expires_at"] < utcnow_iso():
            return False, "invalid", 0, None
        if promo["max_uses"] and promo["used_count"] >= promo["max_uses"]:
            return False, "invalid", 0, None
        async with self._db() as db:
            async with db.execute(
                "SELECT 1 FROM promo_usages WHERE promo_id=? AND user_id=?",
                (promo["id"], user_id)) as cur:
                if await cur.fetchone():
                    return False, "used", 0, None
        if promo["kind"] == "percent":
            discount = subtotal_cents * promo["value"] // 100
        else:
            discount = min(promo["value"], subtotal_cents)
        return True, "ok", discount, promo

    async def record_promo_usage(self, promo_id: int, user_id: int) -> bool:
        """Atomically consume one promo use for a user.

        Returns True when the use was recorded. Returns False when the user
        already used it (INSERT OR IGNORE hit) or the promo hit max_uses in
        a race (the usage row is rolled back). Callers should treat False as
        "do not apply the discount".
        """
        async with self._db() as db:
            cur = await db.execute(
                "INSERT OR IGNORE INTO promo_usages(promo_id, user_id, used_at)"
                " VALUES (?, ?, ?)",
                (promo_id, user_id, utcnow_iso()),
            )
            if cur.rowcount == 0:
                return False  # this user already consumed it
            cur = await db.execute(
                "UPDATE promos SET used_count = used_count + 1"
                " WHERE id=? AND (max_uses = 0 OR used_count < max_uses)",
                (promo_id,),
            )
            if cur.rowcount == 0:
                # Lost the race for the last slot: roll back our usage row.
                await db.execute(
                    "DELETE FROM promo_usages WHERE promo_id=? AND user_id=?",
                    (promo_id, user_id),
                )
                await db.commit()
                return False
            await db.commit()
            return True

    async def release_promo_usage(self, promo_id: int, user_id: int) -> bool:
        """Release a promo claim (e.g. order cancelled before payment).

        Audit M2: promo usages were never released on cancellation, so users
        lost single-use promos on unpaid orders. Returns True if a claim
        was released.
        """
        async with self._db() as db:
            cur = await db.execute(
                "DELETE FROM promo_usages WHERE promo_id=? AND user_id=?",
                (promo_id, user_id),
            )
            released = cur.rowcount > 0
            if released:
                await db.execute(
                    "UPDATE promos SET used_count = MAX(0, used_count - 1)"
                    " WHERE id=?",
                    (promo_id,),
                )
            await db.commit()
            return released

    async def release_order_promo(self, order_id: int) -> bool:
        """Release the promo claimed for an order, if any."""
        order = await self.get_order(order_id)
        if not order or not order["promo_code"]:
            return False
        promo = await self.get_promo(order["promo_code"])
        if not promo:
            return False
        return await self.release_promo_usage(promo["id"], order["user_id"])

    async def list_promos(self):
        async with self._db() as db:
            async with db.execute("SELECT * FROM promos ORDER BY id DESC") as cur:
                return await cur.fetchall()

    async def add_promo(self, *, code, kind, value, max_uses=0, expires_at=None) -> int:
        async with self._db() as db:
            cur = await db.execute(
                "INSERT INTO promos(code, kind, value, max_uses, expires_at)"
                " VALUES (?, ?, ?, ?, ?)",
                (code.strip().upper(), kind, value, max_uses, expires_at),
            )
            await db.commit()
            return cur.lastrowid

    async def set_promo_active(self, promo_id: int, active: bool):
        async with self._db() as db:
            await db.execute("UPDATE promos SET is_active=? WHERE id=?",
                             (1 if active else 0, promo_id))
            await db.commit()

    async def delete_promo(self, promo_id: int):
        async with self._db() as db:
            await db.execute("DELETE FROM promos WHERE id=?", (promo_id,))
            await db.commit()

    # --------------------------------------------------------- orders ---
    async def create_order(self, *, user_id, subtotal_cents, discount_cents,
                           total_cents, payment_method, delivery_kind,
                           address, phone, promo_code=None) -> int:
        now = utcnow_iso()
        async with self._db() as db:
            cur = await db.execute(
                "INSERT INTO orders(user_id, status, subtotal_cents, discount_cents,"
                " total_cents, payment_method, delivery_kind, address, phone,"
                " promo_code, created_at, updated_at)"
                " VALUES (?, 'pending', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (user_id, subtotal_cents, discount_cents, total_cents,
                 payment_method, delivery_kind, address, phone, promo_code,
                 now, now),
            )
            await db.commit()
            return cur.lastrowid

    async def add_order_item(self, order_id: int, product_id: int, name: str,
                             qty: int, price_cents: int):
        async with self._db() as db:
            await db.execute(
                "INSERT INTO order_items(order_id, product_id, name, qty, price_cents)"
                " VALUES (?, ?, ?, ?, ?)",
                (order_id, product_id, name, qty, price_cents),
            )
            await db.commit()

    async def set_order_item_value(self, order_id: int, product_id: int, value: str):
        async with self._db() as db:
            await db.execute(
                "UPDATE order_items SET delivered_value=? WHERE order_id=? AND product_id=?",
                (value, order_id, product_id),
            )
            await db.commit()

    async def get_order(self, order_id: int):
        async with self._db() as db:
            async with db.execute("SELECT * FROM orders WHERE id=?",
                                  (order_id,)) as cur:
                return await cur.fetchone()

    async def get_order_items(self, order_id: int):
        async with self._db() as db:
            async with db.execute(
                "SELECT * FROM order_items WHERE order_id=?", (order_id,)) as cur:
                return await cur.fetchall()

    async def list_user_orders(self, user_id: int, limit: int, offset: int):
        async with self._db() as db:
            async with db.execute(
                "SELECT * FROM orders WHERE user_id=? ORDER BY id DESC LIMIT ? OFFSET ?",
                (user_id, limit, offset)) as cur:
                return await cur.fetchall()

    async def count_user_orders(self, user_id: int) -> int:
        async with self._db() as db:
            async with db.execute(
                "SELECT COUNT(*) c FROM orders WHERE user_id=?",
                (user_id,)) as cur:
                return (await cur.fetchone())["c"]

    async def user_spent(self, user_id: int) -> int:
        async with self._db() as db:
            async with db.execute(
                "SELECT COALESCE(SUM(total_cents),0) s FROM orders"
                " WHERE user_id=? AND status != 'cancelled'",
                (user_id,)) as cur:
                return (await cur.fetchone())["s"]

    async def user_paid_orders_count(self, user_id: int) -> int:
        async with self._db() as db:
            async with db.execute(
                "SELECT COUNT(*) c FROM orders WHERE user_id=?"
                " AND status IN ('confirmed','preparing','shipped','delivered')",
                (user_id,)) as cur:
                return (await cur.fetchone())["c"]

    async def list_orders_by_status(self, status: str, limit: int, offset: int):
        async with self._db() as db:
            async with db.execute(
                "SELECT o.*, u.name AS user_name, u.tg_id AS user_tg_id FROM orders o"
                " JOIN users u ON u.id=o.user_id"
                " WHERE o.status=? ORDER BY o.id DESC LIMIT ? OFFSET ?",
                (status, limit, offset)) as cur:
                return await cur.fetchall()

    async def count_orders_by_status(self, status: str) -> int:
        async with self._db() as db:
            async with db.execute(
                "SELECT COUNT(*) c FROM orders WHERE status=?", (status,)) as cur:
                return (await cur.fetchone())["c"]

    async def orders_by_status_counts(self) -> dict:
        async with self._db() as db:
            async with db.execute(
                "SELECT status, COUNT(*) c FROM orders GROUP BY status") as cur:
                return {r["status"]: r["c"] for r in await cur.fetchall()}

    async def set_order_status(self, order_id: int, status: str):
        async with self._db() as db:
            await db.execute(
                "UPDATE orders SET status=?, updated_at=? WHERE id=?",
                (status, utcnow_iso(), order_id),
            )
            await db.commit()

    async def revenue(self, days: int = None) -> tuple:
        """Returns (revenue_cents, order_count) for non-cancelled orders."""
        q = ("SELECT COALESCE(SUM(total_cents),0) s, COUNT(*) c FROM orders"
             " WHERE status != 'cancelled'")
        args: tuple = ()
        if days:
            q += " AND created_at >= datetime('now', ?)"
            args = (f"-{days} days",)
        async with self._db() as db:
            async with db.execute(q, args) as cur:
                row = await cur.fetchone()
                return row["s"], row["c"]

    async def avg_check(self) -> int:
        async with self._db() as db:
            async with db.execute(
                "SELECT COALESCE(AVG(total_cents),0) a FROM orders"
                " WHERE status != 'cancelled'") as cur:
                return int((await cur.fetchone())["a"] or 0)

    # ------------------------------------------------------- payments ---
    async def record_payment(self, *, provider, external_id, user_id, order_id,
                             amount_cents, currency, status="paid") -> bool:
        """Idempotent insert. Returns True if this is a NEW payment."""
        try:
            async with self._db() as db:
                await db.execute(
                    "INSERT INTO payments(provider, external_id, user_id, order_id,"
                    " amount_cents, currency, status, created_at)"
                    " VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (provider, external_id, user_id, order_id, amount_cents,
                     currency, status, utcnow_iso()),
                )
                await db.commit()
                return True
        except aiosqlite.IntegrityError:
            return False

    # -------------------------------------------------------- reviews ---
    async def has_purchased(self, user_id: int, product_id: int) -> bool:
        async with self._db() as db:
            async with db.execute(
                "SELECT 1 FROM order_items oi JOIN orders o ON o.id=oi.order_id"
                " WHERE o.user_id=? AND oi.product_id=?"
                " AND o.status IN ('confirmed','preparing','shipped','delivered')",
                (user_id, product_id)) as cur:
                return await cur.fetchone() is not None

    async def add_review(self, user_id: int, product_id: int, rating: int, text: str = ""):
        async with self._db() as db:
            await db.execute(
                "INSERT INTO reviews(user_id, product_id, rating, text, created_at)"
                " VALUES (?, ?, ?, ?, ?)"
                " ON CONFLICT(user_id, product_id) DO UPDATE"
                " SET rating=excluded.rating, text=excluded.text,"
                " created_at=excluded.created_at",
                (user_id, product_id, rating, text, utcnow_iso()),
            )
            await db.execute(
                "UPDATE products SET rating_sum=(SELECT COALESCE(SUM(rating),0)"
                " FROM reviews WHERE product_id=?),"
                " rating_count=(SELECT COUNT(*) FROM reviews WHERE product_id=?)"
                " WHERE id=?",
                (product_id, product_id, product_id),
            )
            await db.commit()

    async def list_reviews(self, product_id: int, limit: int = 10):
        async with self._db() as db:
            async with db.execute(
                "SELECT r.*, u.name AS user_name FROM reviews r"
                " JOIN users u ON u.id=r.user_id"
                " WHERE r.product_id=? ORDER BY r.created_at DESC LIMIT ?",
                (product_id, limit)) as cur:
                return await cur.fetchall()

    async def user_purchased_products(self, user_id: int):
        async with self._db() as db:
            async with db.execute(
                "SELECT DISTINCT p.* FROM order_items oi"
                " JOIN orders o ON o.id=oi.order_id"
                " JOIN products p ON p.id=oi.product_id"
                " WHERE o.user_id=?"
                " AND o.status IN ('confirmed','preparing','shipped','delivered')",
                (user_id,)) as cur:
                return await cur.fetchall()

    # ------------------------------------------------------ referrals ---
    async def record_referral_earning(self, referrer_id: int, referee_id: int,
                                      order_id: int, amount_cents: int):
        async with self._db() as db:
            await db.execute(
                "INSERT OR IGNORE INTO referral_earnings"
                "(referrer_id, referee_id, order_id, amount_cents, created_at)"
                " VALUES (?, ?, ?, ?, ?)",
                (referrer_id, referee_id, order_id, amount_cents, utcnow_iso()),
            )
            await db.commit()

    async def try_claim_first_referral_credit(self, referee_id: int) -> bool:
        """Atomically claim the one-time first-paid-order referral credit.

        Returns True only for the winner: the PRIMARY KEY on referee_id makes
        concurrent first orders serialize — exactly one INSERT wins, so two
        simultaneous first orders can never double-credit.

        Intended wiring (handlers/common.py::maybe_credit_referral): replace
        the `user_paid_orders_count(...) != 1` check with
        `if not await db.try_claim_first_referral_credit(user["id"]): return 0`.
        """
        try:
            async with self._db() as db:
                cur = await db.execute(
                    "INSERT OR IGNORE INTO referral_claims(referee_id, claimed_at)"
                    " VALUES (?, ?)",
                    (referee_id, utcnow_iso()),
                )
                await db.commit()
                return cur.rowcount > 0
        except Exception:
            return False

    async def referral_earnings_total(self, user_id: int) -> int:
        async with self._db() as db:
            async with db.execute(
                "SELECT COALESCE(SUM(amount_cents),0) s FROM referral_earnings"
                " WHERE referrer_id=?",
                (user_id,)) as cur:
                return (await cur.fetchone())["s"]

    async def referral_count(self, user_id: int) -> int:
        async with self._db() as db:
            async with db.execute(
                "SELECT COUNT(*) c FROM users WHERE referred_by=?",
                (user_id,)) as cur:
                return (await cur.fetchone())["c"]

    async def admin_tg_ids(self):
        async with self._db() as db:
            async with db.execute(
                "SELECT tg_id, role_mask FROM users WHERE role_mask != 0") as cur:
                return [(r["tg_id"], r["role_mask"]) for r in await cur.fetchall()]

    async def values_total_count(self, product_id: int) -> int:
        async with self._db() as db:
            async with db.execute(
                "SELECT COUNT(*) c FROM product_values WHERE product_id=?",
                (product_id,)) as cur:
                return (await cur.fetchone())["c"]

    # ---------------------------------------------------------- audit ---
    async def audit(self, actor_tg_id: int, action: str, details: str = ""):
        async with self._db() as db:
            await db.execute(
                "INSERT INTO audit_log(ts, actor_tg_id, action, details)"
                " VALUES (?, ?, ?, ?)",
                (utcnow_iso(), actor_tg_id, action, details),
            )
            await db.commit()

    # ---------------------------------------------------------- crypto ---
    async def next_xpub_index(self, chain: str) -> int:
        """Atomically fetch-and-increment the per-chain derivation index.

        Index 0 is reserved; counting starts at 1. Single-statement
        UPSERT...RETURNING so concurrent checkouts can't get the same index
        (which would reuse a deposit address across two orders).
        """
        key = f"xpub_index_{chain}"
        async with self._db() as db:
            async with db.execute(
                "INSERT INTO kv(key, value) VALUES (?, '1') "
                "ON CONFLICT(key) DO UPDATE "
                "SET value = CAST(kv.value AS INTEGER) + 1 "
                "RETURNING value",
                (key,),
            ) as cur:
                row = await cur.fetchone()
            await db.commit()
            return max(int(row["value"]), 1)

    async def crypto_chain_enabled(self, chain: str) -> bool:
        return (await self.kv_get(f"crypto_{chain}_enabled", "1")) == "1"

    async def set_crypto_chain_enabled(self, chain: str, enabled: bool):
        await self.kv_set(f"crypto_{chain}_enabled", "1" if enabled else "0")

    async def create_crypto_deposit(self, *, order_id: int, chain: str,
                                    address: str, derivation_index=None,
                                    memo=None, expected_crypto: str,
                                    expected_usd_cents: int,
                                    expires_at: str) -> int:
        async with self._db() as db:
            cur = await db.execute(
                "INSERT INTO crypto_deposits(order_id, chain, address,"
                " derivation_index, memo, expected_crypto, expected_usd_cents,"
                " status, created_at, expires_at)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?)",
                (order_id, chain, address, derivation_index, memo,
                 expected_crypto, expected_usd_cents, utcnow_iso(), expires_at),
            )
            await db.commit()
            return cur.lastrowid

    async def get_crypto_deposit(self, deposit_id: int):
        async with self._db() as db:
            async with db.execute("SELECT * FROM crypto_deposits WHERE id=?",
                                  (deposit_id,)) as cur:
                return await cur.fetchone()

    async def get_deposit_by_order(self, order_id: int, chain: str = None):
        q = "SELECT * FROM crypto_deposits WHERE order_id=? ORDER BY id DESC LIMIT 1"
        args = (order_id,)
        if chain:
            q = ("SELECT * FROM crypto_deposits WHERE order_id=? AND chain=?"
                 " ORDER BY id DESC LIMIT 1")
            args = (order_id, chain)
        async with self._db() as db:
            async with db.execute(q, args) as cur:
                return await cur.fetchone()

    async def pending_crypto_deposits(self):
        async with self._db() as db:
            async with db.execute(
                    "SELECT * FROM crypto_deposits WHERE status='pending'") as cur:
                return await cur.fetchall()

    async def update_crypto_deposit(self, deposit_id: int, **fields):
        if not fields:
            return
        cols = ", ".join(f"{k}=?" for k in fields)
        async with self._db() as db:
            await db.execute(f"UPDATE crypto_deposits SET {cols} WHERE id=?",
                             (*fields.values(), deposit_id))
            await db.commit()

    async def claim_crypto_deposit(self, deposit_id: int, txid: str,
                                   seen_amount_crypto: str,
                                   confirmations: int) -> bool:
        """Atomically claim a deposit for finalization. Returns True only for
        the winner of the race.

        The guard is STATUS-based (pending/underpaid/late) and the UPDATE flips
        status to 'paid' in the same statement, so a concurrent second claim
        sees status='paid' and gets rowcount 0. It is deliberately NOT
        txid-IS-NULL: the first underpaid detection already writes a txid, and
        a top-up that brings the total over tolerance must still claim.
        UNIQUE(chain, txid) violations also return False.
        """
        try:
            async with self._db() as db:
                cur = await db.execute(
                    "UPDATE crypto_deposits SET txid=?, seen_amount_crypto=?,"
                    " confirmations=?, status='paid'"
                    " WHERE id=? AND status IN ('pending','underpaid','late')",
                    (txid, seen_amount_crypto, confirmations, deposit_id),
                )
                await db.commit()
                return cur.rowcount > 0
        except Exception:
            return False

    async def list_crypto_deposits(self, status: str = None, limit: int = 50):
        q = "SELECT * FROM crypto_deposits"
        args = ()
        if status:
            q += " WHERE status=?"
            args = (status,)
        q += " ORDER BY id DESC LIMIT ?"
        async with self._db() as db:
            async with db.execute(q, (*args, limit)) as cur:
                return await cur.fetchall()

    async def create_cryptobot_invoice(self, *, order_id: int, invoice_id: int,
                                       asset: str, amount: str) -> int:
        async with self._db() as db:
            cur = await db.execute(
                "INSERT INTO cryptobot_invoices(order_id, invoice_id, asset,"
                " amount, status, created_at) VALUES (?, ?, ?, ?, 'active', ?)",
                (order_id, invoice_id, asset, amount, utcnow_iso()),
            )
            await db.commit()
            return cur.lastrowid

    async def get_cryptobot_invoice(self, invoice_id: int):
        async with self._db() as db:
            async with db.execute(
                    "SELECT * FROM cryptobot_invoices WHERE invoice_id=?",
                    (invoice_id,)) as cur:
                return await cur.fetchone()

    async def active_cryptobot_invoices(self):
        async with self._db() as db:
            async with db.execute(
                    "SELECT * FROM cryptobot_invoices WHERE status='active'"
            ) as cur:
                return await cur.fetchall()

    async def expire_stale_cryptobot_invoices(self, ttl_minutes: int = 45) -> int:
        """Expire invoices past their TTL server-side.

        Audit M5: invoices stayed 'active' forever (expiry lived only on
        CryptoBot's side), so the 60s poller scanned an unbounded list and
        stale invoices could finalize per C7. Returns count expired.
        """
        cutoff = (datetime.now(timezone.utc) -
                  timedelta(minutes=ttl_minutes)).isoformat()
        async with self._db() as db:
            cur = await db.execute(
                "UPDATE cryptobot_invoices SET status='expired'"
                " WHERE status='active' AND created_at < ?",
                (cutoff,))
            n = cur.rowcount
            await db.commit()
            return n

    async def set_cryptobot_status(self, invoice_id: int, status: str):
        async with self._db() as db:
            await db.execute("UPDATE cryptobot_invoices SET status=? WHERE invoice_id=?",
                             (status, invoice_id))
            await db.commit()
